export const metadata = {
  title: 'Simple Bell Timer',
  description: 'A simple bell timer app',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
