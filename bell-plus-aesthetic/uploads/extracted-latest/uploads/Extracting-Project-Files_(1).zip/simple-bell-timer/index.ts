// This is a placeholder file
// The Next.js app is in the src/app directory
console.log("Starting Next.js app...");

// Redirect to the Next.js app
window.location.href = '/src/app';
