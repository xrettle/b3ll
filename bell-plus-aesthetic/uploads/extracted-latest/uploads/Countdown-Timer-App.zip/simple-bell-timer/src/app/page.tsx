export default function Home() {
  return (
    <main style={{ padding: '2rem', textAlign: 'center' }}>
      <h1 style={{ fontSize: '2rem', marginBottom: '1rem' }}>Bell Timer</h1>
      <p>A simple bell timer application</p>
    </main>
  );
}
