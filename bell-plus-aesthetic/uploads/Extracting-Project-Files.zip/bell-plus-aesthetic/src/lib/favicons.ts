/**
 * Dynamic favicon utility
 * Updates the favicon color based on remaining time
 *
 * Color scheme:
 * - > 6 minutes: #8B9A71 (green)
 * - 2-6 minutes: #fdb580 (orange)
 * - < 2 minutes: #6E2032 (dark red)
 * - < 30 seconds: Flashing between #6E2032 and #e02f58
 */

// Cache for the favicon elements
let faviconElement: HTMLLinkElement | null = null;
let flashingInterval: NodeJS.Timeout | null = null;

// Colors for different time thresholds
const COLORS = {
  DEFAULT: '#8B9A71',   // > 6 minutes
  WARNING: '#fdb580',   // 2-6 minutes
  URGENT: '#6E2032',    // < 2 minutes
  FLASH: '#e02f58'      // Flash color for < 30 seconds
};

/**
 * Create the favicon link element if it doesn't exist
 */
function ensureFaviconExists(): void {
  if (faviconElement === null) {
    // Look for existing favicon
    const existingFavicon = document.querySelector('link[rel="icon"]');

    if (existingFavicon) {
      faviconElement = existingFavicon as HTMLLinkElement;
    } else {
      // Create a new favicon link element
      faviconElement = document.createElement('link');
      faviconElement.rel = 'icon';
      faviconElement.type = 'image/svg+xml';
      document.head.appendChild(faviconElement);
    }
  }
}

/**
 * Generate SVG favicon with specified color
 */
function generateFavicon(color: string): string {
  return `
    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
      <rect id="favicon-rect" x="2" y="2" width="28" height="28" rx="8" ry="8" fill="${color}" />
    </svg>
  `;
}

/**
 * Update the favicon with specified color
 */
function updateFaviconColor(color: string): void {
  if (typeof window === 'undefined') return;

  ensureFaviconExists();

  if (faviconElement) {
    const svgData = generateFavicon(color);
    const encodedData = encodeURIComponent(svgData);
    const faviconUrl = `data:image/svg+xml,${encodedData}`;

    faviconElement.href = faviconUrl;
  }
}

/**
 * Stop any ongoing flashing effect
 */
function stopFlashing(): void {
  if (flashingInterval) {
    clearInterval(flashingInterval);
    flashingInterval = null;
  }
}

/**
 * Start flashing effect between two colors
 */
function startFlashing(urgentColor: string, flashColor: string, intervalMs: number = 500): void {
  if (typeof window === 'undefined') return;

  stopFlashing();

  let useFlashColor = false;

  flashingInterval = setInterval(() => {
    updateFaviconColor(useFlashColor ? flashColor : urgentColor);
    useFlashColor = !useFlashColor;
  }, intervalMs);
}

/**
 * Update favicon based on remaining time
 * @param timeLeftMs Time left in milliseconds
 */
export function updateFaviconStatus(timeLeftMs: number): void {
  if (typeof window === 'undefined') return;

  const sixMinutesMs = 6 * 60 * 1000;
  const twoMinutesMs = 2 * 60 * 1000;
  const thirtySecondsMs = 30 * 1000;

  // Stop any existing flashing
  stopFlashing();

  if (timeLeftMs > sixMinutesMs) {
    // More than 6 minutes: Default color (green)
    updateFaviconColor(COLORS.DEFAULT);
  } else if (timeLeftMs > twoMinutesMs) {
    // Between 2-6 minutes: Warning color (orange)
    updateFaviconColor(COLORS.WARNING);
  } else if (timeLeftMs > thirtySecondsMs) {
    // Between 30s-2m: Urgent color (dark red)
    updateFaviconColor(COLORS.URGENT);
  } else {
    // Less than 30 seconds: Flashing effect
    startFlashing(COLORS.URGENT, COLORS.FLASH);
  }
}

/**
 * Reset favicon to default state
 */
export function resetFavicon(): void {
  stopFlashing();
  updateFaviconColor(COLORS.DEFAULT);
}
